"""Backend СТАС."""
