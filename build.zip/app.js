const API = "http://127.0.0.1:8000";

const questions = [
    { key: "full_name", type: "text", title: "1. ФИО спортсмена (ребенка):", placeholder: "Например: Кожевникова Василиса" },
    { key: "birth_date", type: "date", title: "2. Дата рождения:", placeholder: "" },
    { key: "sex", type: "choice", title: "3. Укажите пол:", options: [{ label: "👦 Мальчик / Мужчина", val: "male" }, { label: "👧 Девочка / Женщина", val: "female" }] },
    { key: "height", type: "number", title: "4. Рост спортсмена (в см):", placeholder: "Например: 116" },
    { key: "weight", type: "number", title: "5. Вес спортсмена (в кг):", placeholder: "Например: 22" },
    { key: "father_height", type: "number", title: "6. Рост отца (в см) — генетический прогноз:", placeholder: "Например: 182 (можно пропустить)" },
    { key: "mother_height", type: "number", title: "7. Рост матери (в см) — генетический прогноз:", placeholder: "Например: 168 (можно пропустить)" },
    { key: "speed", type: "choice", title: "8. Скоростные способности:", options: [{ label: "Низкие", val: 2 }, { label: "Средние", val: 6 }, { label: "Высокие", val: 8 }, { label: "Отличные", val: 10 }] },
    { key: "strength", type: "choice", title: "9. Силовые способности:", options: [{ label: "Низкие", val: 2 }, { label: "Средние", val: 6 }, { label: "Высокие", val: 8 }, { label: "Отличные", val: 10 }] },
    { key: "coordination", type: "choice", title: "10. Координационные способности:", options: [{ label: "Низкие", val: 2 }, { label: "Средние", val: 6 }, { label: "Высокие", val: 8 }, { label: "Отличные", val: 10 }] },
    { key: "flexibility", type: "choice", title: "11. Гибкость:", options: [{ label: "Низкая", val: 2 }, { label: "Средняя", val: 6 }, { label: "Хорошая", val: 8 }, { label: "Отличная", val: 10 }] },
    { key: "endurance", type: "choice", title: "12. Выносливость:", options: [{ label: "Низкая", val: 2 }, { label: "Средняя", val: 6 }, { label: "Высокая", val: 8 }, { label: "Отличная", val: 10 }] },
    
    // Опросник темперамента Белова / Айзенка (4 вопроса)
    { key: "temp_q1", type: "choice", title: "13. Опросник Белова (1/4): Поведение при высокой активности и нагрузках:", options: [
        { label: "🏃 Энергично переключается, быстро адаптируется (Сангвиник)", val: "sanguine" },
        { label: "🔥 Бурно реагирует, вспыльчив, неудержим (Холерик)", val: "choleric" },
        { label: "🧘 Спокоен, выдержан, тщательно анализирует (Флегматик)", val: "phlegmatic" },
        { label: "🎨 Быстро устает психически, раним, переживает (Меланхолик)", val: "melancholic" }
    ]},
    { key: "temp_q2", type: "choice", title: "14. Опросник Белова (2/4): Принятие решений в соревновательных ситуациях:", options: [
        { label: "⚡ Быстро, легко и обдуманно (Сангвиник)", val: "sanguine" },
        { label: "💥 Мгновенно, рискованно, агрессивно (Холерик)", val: "choleric" },
        { label: "🎯 Медленно, взвешенно, без суеты (Флегматик)", val: "phlegmatic" },
        { label: "🛡️ Осторожно, сомневаясь (Меланхолик)", val: "melancholic" }
    ]},
    { key: "temp_q3", type: "choice", title: "15. Опросник Белова (3/4): Общение в команде и с тренером:", options: [
        { label: "🗣️ Общительный, лидер, оптимистичный (Сангвиник)", val: "sanguine" },
        { label: "✊ Эмоциональный, отстаивает мнение (Холерик)", val: "choleric" },
        { label: "🤝 Неразговорчивый, ровный, дисциплинированный (Флегматик)", val: "phlegmatic" },
        { label: "🤫 Скромный, тихий, чуткий (Меланхолик)", val: "melancholic" }
    ]},
    { key: "temp_q4", type: "choice", title: "16. Опросник Белова (4/4): Реакция на монотонную тренировочную работу:", options: [
        { label: "🔄 Нуждается в разнообразии заданий (Сангвиник)", val: "sanguine" },
        { label: "⚡ Быстро утомляется от рутины, рвется к борьбе (Холерик)", val: "choleric" },
        { label: "⚙️ Отлично выполняет длительную рутинную работу (Флегматик)", val: "phlegmatic" },
        { label: "🕊️ Нуждается в частых паузах и поддержке (Меланхолик)", val: "melancholic" }
    ]}
];

let currentStep = 0;
let userAnswers = {};

// Переменные Теппинг-теста Ильина
let tapIntervals = [0, 0, 0, 0, 0, 0];
let currentIntervalIdx = 0;
let tapTimerToken = null;
let tapSecondsLeft = 30;
let totalTapCount = 0;
let isTappingActive = false;

document.addEventListener("DOMContentLoaded", () => {
    checkApi();
});

async function checkApi() {
    const apiStatus = document.getElementById("apiStatus");
    try {
        const response = await fetch(`${API}/api/health`);
        if (response.ok && apiStatus) {
            apiStatus.textContent = "STAS API: Подключено";
            apiStatus.style.background = "#e8f9e9";
            apiStatus.style.color = "#15803d";
        }
    } catch (e) {
        if (apiStatus) {
            apiStatus.textContent = "API недоступен";
            apiStatus.style.background = "#ffeefe";
            apiStatus.style.color = "#e64646";
        }
    }
}

window.startQuiz = function() {
    currentStep = 0;
    userAnswers = {};
    document.getElementById("welcomeScreen").classList.add("hidden");
    document.getElementById("quizScreen").classList.remove("hidden");
    showQuestion();
};

function showQuestion() {
    const q = questions[currentStep];
    const container = document.getElementById("questionContainer");
    const indicator = document.getElementById("stepIndicator");
    const progress = document.getElementById("progressFill");
    const prevBtn = document.getElementById("prevBtn");

    if (indicator) indicator.textContent = `Шаг ${currentStep + 1} из ${questions.length}`;
    if (progress) progress.style.width = `${((currentStep + 1) / questions.length) * 100}%`;
    if (prevBtn) prevBtn.style.display = currentStep > 0 ? "inline-block" : "none";

    let html = `<div class="question-title">${q.title}</div>`;

    if (q.type === "text" || q.type === "number" || q.type === "date") {
        const existingVal = userAnswers[q.key] || "";
        const inputType = q.type === "number" ? "number" : (q.type === "date" ? "date" : "text");
        html += `
            <input type="${inputType}" id="quizInput" class="input-field" placeholder="${q.placeholder}" value="${existingVal}" autofocus>
            <button type="button" class="btn-primary" onclick="submitInputAnswer()">Далее ➔</button>
        `;
    } else {
        html += `<div class="options-list">`;
        q.options.forEach(opt => {
            const isSelected = userAnswers[q.key] === opt.val ? "selected" : "";
            html += `
                <button type="button" class="option-btn ${isSelected}" onclick="selectChoiceAnswer('${q.key}', '${opt.val}')">
                    ${opt.label}
                </button>
            `;
        });
        html += `</div>`;
    }

    if (container) container.innerHTML = html;
}

window.selectChoiceAnswer = function(key, val) {
    userAnswers[key] = val;
    setTimeout(() => {
        if (currentStep < questions.length - 1) {
            currentStep++;
            showQuestion();
        } else {
            openTappingTestScreen();
        }
    }, 180);
};

window.submitInputAnswer = function() {
    const input = document.getElementById("quizInput");
    const q = questions[currentStep];

    if ((q.key === "father_height" || q.key === "mother_height") && (!input || !input.value)) {
        userAnswers[q.key] = null;
    } else if (!input || !input.value) {
        alert("Пожалуйста, введите значение");
        return;
    } else {
        userAnswers[q.key] = q.type === "number" ? Number(input.value) : input.value;
    }

    if (currentStep < questions.length - 1) {
        currentStep++;
        showQuestion();
    } else {
        openTappingTestScreen();
    }
};

window.prevStep = function() {
    if (currentStep > 0) {
        currentStep--;
        showQuestion();
    }
};

// ТЕППИНГ-ТЕСТ ИЛЬИНА
function openTappingTestScreen() {
    document.getElementById("quizScreen").classList.add("hidden");
    document.getElementById("tappingScreen").classList.remove("hidden");
}

window.startTappingTest = function() {
    tapIntervals = [0, 0, 0, 0, 0, 0];
    currentIntervalIdx = 0;
    tapSecondsLeft = 30;
    totalTapCount = 0;
    isTappingActive = true;

    document.getElementById("startTapBtn").style.display = "none";
    const zone = document.getElementById("tapArea");
    zone.classList.add("active");
    document.getElementById("tapPromptText").style.display = "none";
    document.getElementById("tapCountDisplay").style.display = "block";
    document.getElementById("tapCountDisplay").textContent = "0";

    tapTimerToken = setInterval(() => {
        tapSecondsLeft--;
        document.getElementById("tapTimer").textContent = tapSecondsLeft;

        currentIntervalIdx = Math.floor((30 - tapSecondsLeft) / 5);
        if (currentIntervalIdx > 5) currentIntervalIdx = 5;

        if (tapSecondsLeft <= 0) {
            clearInterval(tapTimerToken);
            isTappingActive = false;
            finishTappingTest();
        }
    }, 1000);
};

window.registerTap = function() {
    if (!isTappingActive) return;
    totalTapCount++;
    tapIntervals[currentIntervalIdx]++;
    document.getElementById("tapCountDisplay").textContent = totalTapCount;
};

function finishTappingTest() {
    let nerveType = "Ровный (Стабильная НС)";
    const t = tapIntervals;
    if (t[1] > t[0] || t[2] > t[0]) {
        nerveType = "Выпуклый (Сильная НС)";
    } else if (t[0] > t[2] && t[2] > t[4]) {
        nerveType = "Ниспадающий (Слабая / Лабильная НС)";
    } else if (t[2] < t[0] && t[5] > t[2]) {
        nerveType = "Вогнутый (Волнообразная НС)";
    }

    userAnswers.tapping_result = {
        t1: t[0], t2: t[1], t3: t[2], t4: t[3], t5: t[4], t6: t[5],
        total_clicks: totalTapCount,
        nerve_type: nerveType
    };

    sendQuizToBackend();
}

function calculateDominantTemperament() {
    const votes = { sanguine: 0, choleric: 0, phlegmatic: 0, melancholic: 0 };
    ["temp_q1", "temp_q2", "temp_q3", "temp_q4"].forEach(qKey => {
        const val = userAnswers[qKey] || "sanguine";
        if (votes[val] !== undefined) votes[val]++;
    });

    let topTemp = "sanguine";
    let maxVote = -1;
    for (const [temp, count] of Object.entries(votes)) {
        if (count > maxVote) {
            maxVote = count;
            topTemp = temp;
        }
    }
    return topTemp;
}

async function sendQuizToBackend() {
    document.getElementById("tappingScreen").classList.add("hidden");

    const dominantTemp = calculateDominantTemperament();

    const requestData = {
        full_name: userAnswers.full_name || "Кожевникова Василиса",
        birth_date: userAnswers.birth_date || "2019-05-12",
        sex: userAnswers.sex || "female",
        height_cm: userAnswers.height || 116,
        weight_kg: userAnswers.weight || 22,
        father_height_cm: userAnswers.father_height || null,
        mother_height_cm: userAnswers.mother_height || null,
        physical: {
            speed: Number(userAnswers.speed || 6),
            strength: Number(userAnswers.strength || 6),
            coordination: Number(userAnswers.coordination || 6),
            speed_strength: Number(userAnswers.speed || 6),
            flexibility: Number(userAnswers.flexibility || 8),
            endurance: Number(userAnswers.endurance || 6)
        },
        psychology: {
            discipline: 7,
            stress_resistance: 7,
            motivation: 8
        },
        temperament: dominantTemp,
        temperament_answers: {
            behavior: userAnswers.temp_q1 || "sanguine",
            decision: userAnswers.temp_q2 || "sanguine",
            social: userAnswers.temp_q3 || "sanguine",
            monotony: userAnswers.temp_q4 || "sanguine"
        },
        tapping_test: userAnswers.tapping_result || null,
        goal: "health",
        preferences: []
    };

    try {
        const response = await fetch(`${API}/api/analyze`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestData)
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || "Ошибка вычисления");

        renderDashboard(data);

    } catch (error) {
        alert(`Ошибка получения данных: ${error.message}`);
        document.getElementById("welcomeScreen").classList.remove("hidden");
    }
}

function renderDashboard(data) {
    document.getElementById("resultsScreen").classList.remove("hidden");

    const info = data.user_info || {};
    
    // Карточка ребенка
    document.getElementById("resChildName").textContent = info.full_name || "Спортсмен";
    document.getElementById("resChildAgeSex").textContent = `${info.age_years || 5} лет | ${info.sex_label || "Девочка"}`;

    // Прогресс-бары физики
    const phys = info.physical || {};
    setBar("Speed", phys.speed || 6);
    setBar("Strength", phys.strength || 6);
    setBar("Coord", phys.coordination || 6);
    setBar("SpeedStrength", phys.speed_strength || 6);
    setBar("Flex", phys.flexibility || 8);

    // Антропометрия и психофизиология
    document.getElementById("resHeightVal").textContent = `${info.height_cm} см`;
    document.getElementById("resTargetHeightVal").textContent = info.target_adult_height_cm ? `${info.target_adult_height_cm} ± 4 см` : "Не указано";
    document.getElementById("resWeightVal").textContent = `${info.weight_kg} кг`;
    
    const bmi = info.bmi || 16.3;
    let bmiNote = "Норма";
    if (bmi < 18.5) bmiNote = "Дефицит массы";
    else if (bmi >= 25) bmiNote = "Избыток массы";
    document.getElementById("resBmiVal").textContent = `${bmi} (${bmiNote})`;

    const tempMap = { sanguine: "Сангвиник", choleric: "Холерик", phlegmatic: "Флегматик", melancholic: "Меланхолик" };
    document.getElementById("resTemperamentVal").textContent = tempMap[info.temperament] || "Сангвиник";

    const tap = info.tapping_test;
    document.getElementById("resTappingVal").textContent = tap ? `${tap.nerve_type} (${tap.total_clicks} кл)` : "Не проходился";

    // Сетки видов спорта
    const recGrid = document.getElementById("recommendedGrid");
    const trainGrid = document.getElementById("trainGrid");
    recGrid.innerHTML = "";
    trainGrid.innerHTML = "";

    const topSports = data.top_sports || [];

    topSports.forEach((sport, idx) => {
        const percent = Math.round((sport.score || 0) * 10);
        const org = sport.local_availability?.organization_or_object || sport.availability_note || "Всероссийский вид спорта";
        
        const cardHtml = `
            <div class="sport-card">
                <div class="sport-card-info">
                    <h4>${sport.sport_name}</h4>
                    <div class="sport-org">🏛️ ${org}</div>
                </div>
                <div class="circle-score ${percent >= 80 ? 'circle-score-green' : 'circle-score-orange'}">
                    ${percent}%
                </div>
            </div>
        `;

        if (percent >= 80 || idx < 3) {
            recGrid.innerHTML += cardHtml;
        } else {
            trainGrid.innerHTML += cardHtml;
        }
    });

    if (recGrid.children.length === 0) {
        recGrid.innerHTML = `<div style="font-size:13px; color:#6b7280;">Формируются рекомендации ОФП...</div>`;
    }

    if (trainGrid.children.length === 0) {
        trainGrid.innerHTML = `<div style="font-size:13px; color:#6b7280;">Все топ-направления рекомендованы к зачислению!</div>`;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setBar(idKey, score10) {
    const percent = Math.round((score10 / 10) * 100);
    const valEl = document.getElementById(`bar${idKey}Val`);
    const fillEl = document.getElementById(`bar${idKey}Fill`);
    if (valEl) valEl.textContent = `${percent}%`;
    if (fillEl) fillEl.style.width = `${percent}%`;
}

window.restartQuiz = function() {
    document.getElementById("resultsScreen").classList.add("hidden");
    document.getElementById("welcomeScreen").classList.remove("hidden");
};

window.downloadPDF = function() {
    const element = document.getElementById('pdfReportContent');
    const opt = {
        margin:       10,
        filename:     'STAS_Sport_Report.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    if (typeof html2pdf !== 'undefined') {
        html2pdf().from(element).set(opt).save();
    } else {
        alert("Библиотека PDF загружается, попробуйте еще раз.");
    }
};